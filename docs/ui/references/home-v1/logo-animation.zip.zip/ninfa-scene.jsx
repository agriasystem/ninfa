const W = 1672, H = 941;
const SRC = { x: 928, y: 301 }, FIN = { x: 62, y: 70, k: 0.47 };
const P1 = { x: 912, y: 208 }, P2 = { x: 400, y: 66 };
const LEFT = 'M1 22C14 22 30 30 38 46C40 50 40 54 40 58L40 84C18 78 0 60 1 22Z';
const RIGHT = 'M77 24C66 24 52 32 44 46C42 50 42 54 42 60L41 84C62 78 78 56 77 24Z';
const cl = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const sm = (a, b, x) => { x = cl((x - a) / (b - a)); return x * x * (3 - 2 * x); };
const eio = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const MOTION = { flight: eio, text: (x) => 1 - (1 - x) * (1 - x), mask: (x) => x * x * (3 - 2 * x) };

function bez(s) {
  const u = 1 - s, a = u * u * u, b = 3 * u * u * s, c = 3 * u * s * s, d = s * s * s;
  return { x: a * SRC.x + b * P1.x + c * P2.x + d * FIN.x, y: a * SRC.y + b * P1.y + c * P2.y + d * FIN.y };
}
function tan(s) {
  const u = 1 - s;
  const x = 3 * u * u * (P1.x - SRC.x) + 6 * u * s * (P2.x - P1.x) + 3 * s * s * (FIN.x - P2.x);
  const y = 3 * u * u * (P1.y - SRC.y) + 6 * u * s * (P2.y - P1.y) + 3 * s * s * (FIN.y - P2.y);
  const l = Math.hypot(x, y) || 1;
  return { x: x / l, y: y / l };
}
function rng(a) { return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

const PAL = [
  ['#1a55f5', '#2f7bff', '#0f2fbf', '#3fb0ff'],
  ['#5b8cff', '#8aa4ff', '#9a8cff', '#3fb0ff'],
  ['#6f6bff', '#8b7dff', '#4f6bff', '#a99cff'],
];

function build() {
  const r = rng(11), c = document.createElement('canvas').getContext('2d');
  const Lp = new Path2D(LEFT), Rp = new Path2D(RIGHT), Dp = new Path2D(); Dp.arc(40, 10, 10, 0, 7);
  const pts = [];
  while (pts.length < 1100) {
    const x = r() * 78, y = r() * 86;
    const part = c.isPointInPath(Dp, x, y) ? 2 : c.isPointInPath(Lp, x, y) ? 0 : c.isPointInPath(Rp, x, y) ? 1 : -1;
    if (part >= 0) pts.push({ x, y, part });
  }
  const proj = pts.map((p) => -0.25 * (p.x - 39) - (p.y - 43));
  const mn = Math.min(...proj), mx = Math.max(...proj);
  const mk = (p, i, frag) => {
    const u = 1 - (proj[i] - mn) / (mx - mn), z = 0.45 + r() * 1.15, pal = PAL[p.part];
    return {
      lx: p.x - 39, ly: p.y - 43, r: 0.1 + 0.12 * u + r() * 0.012, lag: 0.02 + 0.12 * Math.pow(r(), 1.5), dur: 0.5 + r() * 0.04,
      lat: (r() + r() + r() - 1.5) * 15 * z, al: (r() - 0.5) * 22, ph: r() * 6.28, z, sz: (frag ? 2.6 : 0.7) + z * (frag ? 2.2 : 1.05),
      a0: 0.5 + r() * 0.45, col: pal[(r() * 4) | 0], rot: r() * 6.28, rs: (r() - 0.5) * 9, bright: r() < 0.22,
    };
  };
  const parts = pts.slice(0, 1000).map((p, i) => mk(p, i, false));
  const frags = pts.slice(1000).slice(0, 28).map((p, i) => mk(p, 1000 + i, true));
  const lines = Array.from({ length: 24 }, () => ({ o: (r() - 0.5) * 40, lag: r() * 0.1, len: 0.08 + r() * 0.1, a: 0.3 + r() * 0.5, w: 0.6 + r() * 1.1, col: PAL[(r() * 3) | 0][(r() * 4) | 0] }));
  return { parts, frags, lines };
}

const o1 = {}, o2 = {};
function pos(p, t, o) {
  const s = eio(cl((t - p.r - p.lag) / p.dur));
  const c = bez(s), tg = tan(s), a = sm(0, 0.3, s), b = sm(0.72, 1, s);
  const sc = 1 + (FIN.k - 1) * s, wl = 1 - a + b, ws = a * (1 - b);
  const lat = (p.lat * (0.55 + 0.45 * Math.sin(s * Math.PI)) + Math.sin(s * 11 + p.ph) * 2.2) * ws, al = p.al * ws;
  o.x = c.x + p.lx * sc * wl - tg.y * lat + tg.x * al;
  o.y = c.y + p.ly * sc * wl + tg.x * lat + tg.y * al;
  o.s = s;
}

function draw(ctx, D, t, dens, showPath) {
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  ctx.clearRect(0, 0, W, H);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  if (showPath) {
    ctx.strokeStyle = 'rgba(255,0,80,.5)'; ctx.lineWidth = 1; ctx.beginPath();
    for (let i = 0; i <= 40; i++) { const c = bez(i / 40); i ? ctx.lineTo(c.x, c.y) : ctx.moveTo(c.x, c.y); }
    ctx.stroke();
  }
  if (t < 0.09 || t > 1) return;
  const fade = 1 - sm(0.9, 0.98, t);
  // ribbon
  const sh = eio(cl((t - 0.16) / 0.5)), st = eio(cl((t - 0.3) / 0.5)), env = sm(0.12, 0.2, t) * fade;
  if (sh > 0.001 && env > 0) {
    const N = 28;
    for (let k = 0; k < N; k++) {
      const f = (k + 1) / N, s0 = st + (sh - st) * (k / N), s1 = st + (sh - st) * f, a = bez(s0), b = bez(s1);
      const wp = 3 + 24 * (1 - sm(0, 0.3, s1)) + 9 * sm(0.75, 1, s1) * (1 - sm(0.97, 1, s1));
      const w = wp * (0.2 + 0.8 * Math.pow(f, 1.3)), e = env * Math.pow(f, 1.5);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y);
      ctx.strokeStyle = '#3f7bff'; ctx.globalAlpha = 0.09 * e; ctx.lineWidth = w * 4.2; ctx.stroke();
      ctx.strokeStyle = '#2f6bff'; ctx.globalAlpha = 0.3 * e; ctx.lineWidth = w * 1.5; ctx.stroke();
      ctx.strokeStyle = '#8fd0ff'; ctx.globalAlpha = 0.85 * e; ctx.lineWidth = Math.max(1, w * 0.4); ctx.stroke();
    }
    const hg = bez(sh), he = sm(0.14, 0.24, t) * (1 - sm(0.66, 0.78, t));
    if (he > 0) {
      const g = ctx.createRadialGradient(hg.x, hg.y, 0, hg.x, hg.y, 52);
      g.addColorStop(0, 'rgba(120,190,255,.75)'); g.addColorStop(0.25, 'rgba(60,110,255,.35)'); g.addColorStop(1, 'rgba(90,80,255,0)');
      ctx.globalAlpha = he; ctx.fillStyle = g; ctx.fillRect(hg.x - 52, hg.y - 52, 104, 104);
    }
  }
  // energy lines
  for (const l of D.lines) {
    const sHead = eio(cl((t - 0.16 - l.lag) / 0.5)), eh = sm(0, 0.1, sHead) * (1 - sm(0.85, 1, sHead)) * fade;
    if (eh <= 0.01) continue;
    let pv = null;
    for (let k = 0; k <= 7; k++) {
      const s = eio(cl((t - (k / 7) * l.len - 0.16 - l.lag) / 0.5)), c = bez(s), tg = tan(s);
      const off = l.o * Math.sin(Math.PI * s) * sm(0, 0.25, s), pt = { x: c.x - tg.y * off, y: c.y + tg.x * off };
      if (pv) { ctx.beginPath(); ctx.moveTo(pv.x, pv.y); ctx.lineTo(pt.x, pt.y); ctx.strokeStyle = l.col; ctx.globalAlpha = l.a * eh * Math.pow(1 - k / 8, 1.4); ctx.lineWidth = l.w; ctx.stroke(); }
      pv = pt;
    }
  }
  // particles
  const n = Math.floor(D.parts.length * dens);
  for (let i = 0; i < n; i++) {
    const p = D.parts[i];
    if (t < p.r - 0.005) continue;
    pos(p, t, o1); pos(p, t - 0.016, o2);
    let a = p.a0 * sm(p.r - 0.005, p.r + 0.02, t) * fade * (0.78 + 0.22 * Math.sin(t * 38 + p.ph));
    if (a < 0.02) continue;
    const rad = p.sz * (1 - 0.3 * sm(0.72, 1, o1.s));
    ctx.strokeStyle = p.col; ctx.beginPath(); ctx.moveTo(o2.x, o2.y); ctx.lineTo(o1.x + 0.01, o1.y);
    if (p.bright) { ctx.globalAlpha = a * 0.18; ctx.lineWidth = rad * 6; ctx.stroke(); }
    ctx.globalAlpha = a; ctx.lineWidth = rad * 2; ctx.stroke();
  }
  // fragments
  for (const p of D.frags) {
    if (t < p.r) continue;
    pos(p, t, o1); pos(p, t - 0.02, o2);
    const a = p.a0 * sm(p.r, p.r + 0.02, t) * fade, th = p.rot + o1.s * p.rs, sz = p.sz * (1 - 0.35 * sm(0.72, 1, o1.s));
    ctx.strokeStyle = p.col; ctx.globalAlpha = a * 0.5; ctx.lineWidth = sz * 0.7;
    ctx.beginPath(); ctx.moveTo(o2.x, o2.y); ctx.lineTo(o1.x, o1.y); ctx.stroke();
    ctx.fillStyle = p.col; ctx.globalAlpha = a; ctx.beginPath();
    for (let k = 0; k < 3; k++) { const an = th + k * 2.094, r = k ? sz : sz * 1.8; k ? ctx.lineTo(o1.x + Math.cos(an) * r, o1.y + Math.sin(an) * r) : ctx.moveTo(o1.x + Math.cos(an) * r, o1.y + Math.sin(an) * r); }
    ctx.fill();
  }
  // landing bloom
  const bl = sm(0.76, 0.9, t) * (1 - sm(0.9, 0.99, t));
  if (bl > 0) {
    const g = ctx.createRadialGradient(FIN.x, FIN.y, 0, FIN.x, FIN.y, 60);
    g.addColorStop(0, 'rgba(80,140,255,.4)'); g.addColorStop(1, 'rgba(120,100,255,0)');
    ctx.globalAlpha = bl; ctx.fillStyle = g; ctx.fillRect(FIN.x - 60, FIN.y - 60, 120, 120);
  }
  ctx.globalAlpha = 1;
}

function Logo({ id, x, y, k, e, dir }) {
  // e: edge (0..1 along head->tail axis). dir 'erase': u<e hidden. 'reveal': u<e shown.
  const w = 0.3, o1 = cl(e), o2 = cl(e + w);
  const A = dir === 'erase' ? '#000' : '#fff', B = dir === 'erase' ? '#fff' : '#000';
  return (
    <svg width={78 * k} height={86 * k} viewBox="0 0 78 86" style={{ position: 'absolute', left: x - 39 * k, top: y - 43 * k, overflow: 'visible' }}>
      <defs>
        <linearGradient id={id + 'g'} gradientUnits="userSpaceOnUse" x1="30" y1="0" x2="48" y2="86"><stop offset="0" stopColor={A} /><stop offset={o1} stopColor={A} /><stop offset={o2} stopColor={B} /><stop offset="1" stopColor={B} /></linearGradient>
        <mask id={id + 'm'} maskUnits="userSpaceOnUse" x="-10" y="-10" width="100" height="110"><rect x="-10" y="-10" width="100" height="110" fill={`url(#${id}g)`} /></mask>
        <linearGradient id={id + 'L'} x1="0" y1="0" x2="0.6" y2="1"><stop offset="0" stopColor="#2f7bff" /><stop offset="1" stopColor="#1443e0" /></linearGradient>
        <linearGradient id={id + 'R'} x1="1" y1="0" x2="0.2" y2="1"><stop offset="0" stopColor="#a39bff" /><stop offset="1" stopColor="#5b8cff" /></linearGradient>
        <linearGradient id={id + 'D'} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#5b7bff" /><stop offset="1" stopColor="#8b7dff" /></linearGradient>
      </defs>
      <g mask={`url(#${id}m)`}>
        <path d={LEFT} fill={`url(#${id}L)`} /><path d={RIGHT} fill={`url(#${id}R)`} /><circle cx="40" cy="10" r="10" fill={`url(#${id}D)`} />
      </g>
    </svg>
  );
}

const ic = { fill: 'none', stroke: '#1b1c30', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round' };
const NAV = [
  ['Oggi', 167, <path key="a" d="M3 11.5 12 4l9 7.5V20H3zM9.5 20v-6h5v6" />],
  ['Decisioni', 236, <g key="a"><rect x="4" y="3" width="16" height="18" rx="2.5" /><path d="M8 9h8M8 13h8M8 17h4" /></g>],
  ['Dati', 301, <g key="a"><rect x="3.5" y="12" width="4" height="8" rx="1" /><rect x="10" y="4" width="4" height="16" rx="1" /><rect x="16.5" y="9" width="4" height="11" rx="1" /></g>],
  ['Struttura', 367, <g key="a"><ellipse cx="12" cy="6" rx="8" ry="3" /><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3" /></g>],
];

function Piece({ tw }) {
  const { T, CUES } = useComposition();
  const t = T - CUES.Morph;
  const D = React.useMemo(build, []);
  const cv = React.useRef(null);
  React.useLayoutEffect(() => { if (cv.current) draw(cv.current.getContext('2d'), D, t, tw.density, tw.showPath); });
  const ty = -60 * MOTION.text(cl((t - 0.1) / 0.65));
  const eE = MOTION.mask(cl((t - 0.1) / 0.16)) * 1.3 - 0.3, eR = MOTION.mask(cl((t - 0.8) / 0.18)) * 1.3 - 0.3;
  const full = 'Come recupero i 320 €?', typed = t >= 0 ? full.slice(0, Math.min(full.length, Math.floor(t / 0.055) + 1)) : '';
  const F = { position: 'absolute', fontFamily: 'Poppins, sans-serif' };
  const blue = { color: '#1f6bff' };
  return (
    <div data-screen-label={'t=' + T.toFixed(2)} style={{ ...F, left: 0, top: 0, width: W, height: H, background: '#fff', overflow: 'hidden' }}>
      <div style={{ ...F, left: 241, right: 0, bottom: 0, height: 420, background: 'radial-gradient(ellipse 34% 70% at 34% 100%, rgba(110,185,255,.85), rgba(110,185,255,0) 72%), radial-gradient(ellipse 30% 62% at 74% 100%, rgba(165,145,250,.7), rgba(165,145,250,0) 72%), radial-gradient(ellipse 22% 30% at 50% 100%, rgba(150,240,250,.55), rgba(150,240,250,0) 75%), radial-gradient(ellipse 60% 55% at 50% 100%, rgba(190,200,255,.5), rgba(190,200,255,0) 75%)' }} />
      <div style={{ ...F, left: 240, top: 750, width: 1500, height: 600, borderRadius: '50%', border: '1.5px solid rgba(190,180,255,.55)', WebkitMaskImage: 'linear-gradient(#000 0,transparent 30%)', maskImage: 'linear-gradient(#000 0,transparent 30%)' }} />
      <div style={{ ...F, left: 0, top: 0, width: 241, height: H, background: '#fafbfd', borderRight: '1px solid #ebecf2' }} />
      <div style={{ ...F, left: 13, top: 134, width: 215, height: 67, borderRadius: 18, background: '#e8eefc' }} />
      {NAV.map(([n, y, p], i) => (
        <React.Fragment key={n}>
          <svg width="30" height="30" viewBox="0 0 24 24" style={{ position: 'absolute', left: 43, top: y - 15 }}><g {...ic}>{p}</g></svg>
          <div style={{ ...F, left: 95, top: y - 16, lineHeight: '32px', fontSize: 20, fontWeight: i ? 400 : 500, color: '#1b1c30' }}>{n}</div>
        </React.Fragment>
      ))}
      <div style={{ ...F, left: 41, top: 838, width: 53, height: 53, borderRadius: '50%', background: '#ececf1' }} />
      <svg width="30" height="30" viewBox="0 0 24 24" style={{ position: 'absolute', left: 52, top: 849 }}><g {...ic}><circle cx="12" cy="8" r="4" /><path d="M4.5 21c0-4 3.4-6 7.500-6s7.500 2 7.500 6" /></g></svg>
      <div style={{ ...F, left: 122, top: 848, width: 1, height: 34, background: '#dcdde5' }} />
      <svg width="30" height="30" viewBox="0 0 24 24" style={{ position: 'absolute', left: 156, top: 849 }}><g {...ic}><circle cx="12" cy="12" r="8" strokeWidth="3" strokeDasharray="2.6 3.6" /><circle cx="12" cy="12" r="6.2" /><circle cx="12" cy="12" r="2.6" /></g></svg>
      <div style={{ ...F, left: 0, top: 0, width: 1872, height: 0, textAlign: 'center', transform: `translateY(${ty}px)`, color: '#14152b', fontWeight: 300 }}>
        <div style={{ ...F, left: 0, width: 1872, top: 385, fontSize: 46, lineHeight: '60px' }}>Ciao Luca,</div>
        <div style={{ ...F, left: 0, width: 1872, top: 466, fontSize: 55, lineHeight: '67px' }}>oggi hai <span style={blue}>8 prenotazioni</span><br />e hai perso <span style={blue}>320 € di fatturato.</span></div>
      </div>
      <div style={{ ...F, left: 601, top: 795, width: 675, height: 67, borderRadius: 34, background: 'rgba(255,255,255,.96)', boxShadow: '0 6px 24px rgba(90,110,220,.18)' }}>
        <svg width="28" height="28" viewBox="0 0 24 24" style={{ position: 'absolute', left: 28, top: 20 }}><g {...ic} stroke="#3a3b50"><circle cx="10.5" cy="10.5" r="7" /><path d="m16 16 5 5" /></g></svg>
        <div style={{ ...F, left: 77, top: 0, lineHeight: '67px', fontSize: 20, color: typed ? '#1b1c30' : '#7d7f92' }}>{typed || 'Chiedi a Mia...'}</div>
        <svg width="26" height="30" viewBox="0 0 24 24" style={{ position: 'absolute', left: 625, top: 19 }}><g {...ic}><rect x="9" y="3" width="6" height="11" rx="3" fill="#1b1c30" /><path d="M5.500 11a6.500 6.500 0 0 0 13 0M12 17.500V21" /></g></svg>
      </div>
      <Logo id="s" x={SRC.x} y={SRC.y} k={1} e={eE} dir="erase" />
      <Logo id="f" x={FIN.x} y={FIN.y} k={FIN.k} e={eR} dir="reveal" />
      <canvas ref={cv} width={W * 2} height={H * 2} style={{ position: 'absolute', left: 0, top: 0, width: W, height: H, pointerEvents: 'none' }} />
    </div>
  );
}

function NinfaStage() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={W} height={H} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Piece tw={tw} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Motion" />
        <TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Mostra traiettoria" value={tw.showPath} onChange={(v) => setTweak('showPath', v)} />
        <TweakSlider label="Densità particelle" value={tw.density} min={0.3} max={1} step={0.1} onChange={(v) => setTweak('density', v)} />
      </TweaksPanel>
    </>
  );
}
window.NinfaStage = NinfaStage;
